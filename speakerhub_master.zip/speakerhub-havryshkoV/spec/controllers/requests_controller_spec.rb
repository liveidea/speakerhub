require 'rails_helper'

RSpec.describe RequestsController, type: :controller do

end
