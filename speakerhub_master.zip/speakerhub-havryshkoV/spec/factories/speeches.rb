FactoryGirl.define do
  factory :speech do
    title       "Automation in real life"
    description "Some text"
    place       "Lviv"
    date        Time.now
    account
  end
end