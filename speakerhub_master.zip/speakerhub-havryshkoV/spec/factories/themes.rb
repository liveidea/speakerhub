FactoryGirl.define do
  factory :theme do
    name "Arts"
  end
end
