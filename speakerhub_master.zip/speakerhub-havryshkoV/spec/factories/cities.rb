FactoryGirl.define do
  factory :city do
    name "Lviv"
  end
end