FactoryGirl.define do
  factory :comment do
    
  end
end
