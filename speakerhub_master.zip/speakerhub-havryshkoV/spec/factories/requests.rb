FactoryGirl.define do
  factory :request do
    
  end
end
