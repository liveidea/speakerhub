# require 'rails_helper'

# RSpec.describe "speeches/show", type: :view do
#   before(:each) do
#     @speech = assign(:speech, Speech.create!())
#   end

#   it "renders attributes in <p>" do
#     render
#   end
# end
