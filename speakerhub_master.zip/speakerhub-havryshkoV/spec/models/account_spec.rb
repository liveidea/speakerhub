require 'rails_helper'

# RSpec.describe Account, :type => :model do

#   it "should not be " do
#   	account = build(:account)
#   	account.user = build(:user)
#   	account.create

#   	expect(account1.theme_ids).to eq ['1', '2']
#   end
  
# end