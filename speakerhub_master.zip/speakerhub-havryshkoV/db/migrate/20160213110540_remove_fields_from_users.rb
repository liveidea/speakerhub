class RemoveFieldsFromUsers < ActiveRecord::Migration
  def change
  	#  remove_column :users, :f_name, :string
  	#  remove_column :users, :l_name, :string
  	#  remove_column :users, :phone, :string
  	#  remove_column :users, :facebook_account, :string
  	#  remove_column :users, :skype_account, :string
  end
end
