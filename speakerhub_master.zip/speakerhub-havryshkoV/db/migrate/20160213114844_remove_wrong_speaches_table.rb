class RemoveWrongSpeachesTable < ActiveRecord::Migration
  # def change
  # 	drop_table :speaches
  # end
end
