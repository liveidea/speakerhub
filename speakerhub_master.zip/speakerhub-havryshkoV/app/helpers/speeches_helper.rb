module SpeechesHelper
end
