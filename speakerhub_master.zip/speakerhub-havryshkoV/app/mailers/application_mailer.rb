class ApplicationMailer < ActionMailer::Base
  default from: "havryshko@speakerhub.com"
  layout 'mailer'
end
