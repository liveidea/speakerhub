class City < ActiveRecord::Base
	has_many :accounts
end
