Conference.create(title: "Automation in real life", description: "Some text", place: "Lviv", start_date: DateTime.now + 1.day, finish_date: DateTime.now + 2.day, user_id: "1")
Conference.create(title: "Automation in real life", description: "Some text", place: "Lviv", start_date: DateTime.now + 2.day, finish_date: DateTime.now + 2.day, user_id: "1")
Conference.create(title: "Automation in real life", description: "Some text", place: "Kyiv", start_date: DateTime.now + 2.day, finish_date: DateTime.now + 2.day, user_id: "2")
